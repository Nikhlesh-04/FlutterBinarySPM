#import <Flutter/Flutter.h>

@interface VideoThumbnailPlugin : NSObject <FlutterPlugin>
@end
