#import <Foundation/Foundation.h>

@interface NSString (PM_COMMON)

- (BOOL)isEmpty;

@end
