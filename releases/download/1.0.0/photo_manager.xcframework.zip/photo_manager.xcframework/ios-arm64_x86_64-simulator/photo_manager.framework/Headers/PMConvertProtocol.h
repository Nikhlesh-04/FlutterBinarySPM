#import <Foundation/Foundation.h>

@protocol PMConvertProtocol <NSObject>

- (id)convertData:(NSData *)data;

@end