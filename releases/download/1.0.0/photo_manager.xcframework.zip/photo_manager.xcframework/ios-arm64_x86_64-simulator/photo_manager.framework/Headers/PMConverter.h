#import "PMConvertProtocol.h"
#import <Foundation/Foundation.h>

@interface PMConverter : NSObject <PMConvertProtocol>

@end
