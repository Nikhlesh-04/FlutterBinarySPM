//
//  SwiftyGif.h
//  SwiftyGif
//
//  Created by Scott Hoyt on 1/12/17.
//  Copyright © 2017 alexiscreuzot. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftyGif.
FOUNDATION_EXPORT double SwiftyGifVersionNumber;

//! Project version string for SwiftyGif.
FOUNDATION_EXPORT const unsigned char SwiftyGifVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftyGif/PublicHeader.h>


